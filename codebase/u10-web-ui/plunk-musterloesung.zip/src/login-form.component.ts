import { Input, Component, EventEmitter, Output  } from '@angular/core';

import { LoginCredentials } from './login-credentials';

@Component({
  selector: 'login',
  template: `
    <div>
      <h1>Login</h1>
      <div class="form-group row">
        <div class="col-2">
        
          <label for="name">Name:</label>
        </div>
        <div class="col-8">
          <input [(ngModel)]="loginCredentials.name" type="text" class="form-control" id="name">
        </div>
      </div>
      <div class="form-group row">
        <div class="col-2">
          <label for="password" >Password:</label>
        </div>
        <div class="col-8">
          <input [(ngModel)]="loginCredentials.password" type="password" class="form-control" id="password" />
        </div>
      </div>
    
      <div class="row">
        <div class="col-10">
              <button (click)="doLogin()" type="button" class="btn btn-primary float-right" [disabled]="loginCredentials.isInvalid">Log in '{{loginCredentials.name}}'</button>
        </div>
      </div>
      
    </div>
  `,
})
export class LoginFormComponent implements OnInit  {
    @Input() initalName: string;
    @Output() onLogin: EventEmitter<LoginCredentials> = new EventEmitter<EventEmitter>();
    
    public loginCredentials: LoginCredentials;
   
    public ngOnInit() {
      this.loginCredentials = new LoginCredentials(this.initalName, null);
    }
    
    public doLogin(): void {
       this.onLogin.emit(this.loginCredentials);
    }
}