import { Component } from '@angular/core'

import { LoginService } from './login.service';

@Component({
  selector: 'my-app',
  template: `
    <div>
      <login [initalName]="'lastLogin'" (onLogin)="onLoginFromComponent($event)"> </login>
      Last login: {{lastResult}}
    </div>
  `,
})
export class AppComponent {
  
  private lastResult: boolean;
  
  public constructor(private loginService: LoginService) { 
  }

  public onLoginFromComponent(loginCredentials: LoginCredentials): void {
    var promiseResult: Promise<boolean> = this.loginService.login(loginCredentials);
    promiseResult.then( result => this.lastResult = result );
  }
}