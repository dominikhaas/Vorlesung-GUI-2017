import { NgModule} from '@angular/core'
import { BrowserModule } from '@angular/platform-browser'
import { FormsModule }   from '@angular/forms'; // <-- NgModel lives here

import { AppComponent } from './app.component';
import { LoginFormComponent } from './login-form.component';
import { LoginCredentials } from './login-credentials';
import { LoginService } from './login.service';



@NgModule({
  imports: [ BrowserModule, FormsModule ],
  declarations: [ AppComponent, LoginFormComponent ],
  providers: [ LoginService ],
  bootstrap: [ AppComponent ]
})
export class AppModule {}