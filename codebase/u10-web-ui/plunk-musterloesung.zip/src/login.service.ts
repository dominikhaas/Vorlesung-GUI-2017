import { Injectable } from '@angular/core';

import { LoginCredentials } from './login-credentials';

@Injectable()
export class LoginService {
  
  public login(loginCredentials: LoginCredentials): Promise<boolean> {
      if(loginCredentials && loginCredentials.name == 'lastLogin' && loginCredentials.password == 'pw') {
        return Promise.resolve(true);
      } else {
        return Promise.resolve(false);
      }
  }
}