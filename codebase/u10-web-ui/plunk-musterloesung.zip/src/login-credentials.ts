export class LoginCredentials {
  
  public name: string;
  public password: string;
  
  constructor(name: string, password:string) {
    this.name = name;
    this.password = password;
  }
  
  public get isInvalid(): boolean {
    return !this.isValid;
  }
  
  public get isValid(): boolean {
    return this.name && this.password;
  }
}